package ipages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import projectSpecific.base.ProjectSpecificMethods;

public class Mobilesort extends ProjectSpecificMethods {

	public Mobilesort(RemoteWebDriver driver, ExtentTest node, Properties prop, String Environment, String StageURL,
			String Stage1URL) {
		this.driver = driver;
		this.node = node;
		this.prop = prop;
		this.Environment = Environment;
		this.StageURL = StageURL;
		this.Stage1URL = Stage1URL;
	}

	String url = "";
	String URL;
	
	String propname = "MobileSort/MobileSort";

	@Given("Launch the techpanda URL")
	public Mobilesort LaunchURL() {
		navigateto(StageURL);
		reportStep("techpanda url is launched", "Pass");
		return this;
	}

	@When("Verify Title of the Page")
	public Mobilesort VerifyHomePageTitle() {
		verifyTitle("Home page");
		return this;
	}

	@When("Click on Mobile menu")
	public Mobilesort ClickMobileMenu() throws IOException, InterruptedException {
		click(getprop(propname, "mobiletab"));
		waitTime(3000);
		reportStep("Mobile menu is clicked", "Pass");
		return this;
	}
	
	public Mobilesort VerifyMobilePageTitle() {
		verifyTitle("Mobile");
		return this;
	}

	@When("In the List of all mobiles, select sort by dropdown as name")
	public Mobilesort ClickSortasname() {
		waitTime(5000);
		selectDropDownUsingIndex(driver.findElement(By.xpath("(//select[@title='Sort By'])[1]")), 1);
		return this;
	}

	@Then("Verify all the products are sorted by name")
	public Mobilesort Verifysort() {
		reportStep("Mobile list is sorted", "Pass");
		return this;
	}
}
